#include <cstdio>
#include <iostream>
using namespace std;
int main(){
  int n,k;
  freopen("sum.in","r",stdin);
  freopen("sum.out","w",stdout);
  cin>>n>>k;
  for(int i=1;i<=n*k-n-1;i++)
  cout<<1;
  return 0;
}
